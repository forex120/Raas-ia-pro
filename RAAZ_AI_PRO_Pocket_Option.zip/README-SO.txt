RAAZ AI PRO — Pocket Option OTC 1M

Mashruucan wuxuu leeyahay website mobile-friendly, shumacyo 1-daqiiqo, RSI(14), EMA(9), iyo signal tijaabo ah.

AMNIGA:
- Ha gelin API key-ga HTML ama JavaScript browser-ka.
- Ha ku wadaagin key-ga chat, sawir ama GitHub public.
- API-ga OTCharts waa read-only; ma fuliyo trades.
- Signal-ku ma aha talo maalgashi mana dammaanad qaado faa'iido.

SIDA LOO SHIDO (kombiyuutar/server leh Node.js 18+):
1. Fur terminal gudaha galka mashruuca.
2. Linux/macOS:
   export OTCHARTS_API_KEY='FURAHAAGA'
   node server.js
   Windows PowerShell:
   $env:OTCHARTS_API_KEY='FURAHAAGA'
   node server.js
3. Browser-ka ka fur http://localhost:3000

Hosting:
- Upload mashruuca server taageera Node.js.
- Deji environment variable OTCHARTS_API_KEY gudaha hosting settings.
- Start command: node server.js

Mashruucu si ula kac ah uma sameeyo auto-refresh, si uusan u cunin quota-ga Free.
Liiska Free ee UI-ga: EURUSD_otc, GBPUSD_otc, USDJPY_otc, BTCUSD_otc, AUDUSD_otc.
