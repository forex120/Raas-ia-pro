const http=require("http"),fs=require("fs"),path=require("path");
const key=process.env.OTCHARTS_API_KEY,port=process.env.PORT||3000,root=path.join(__dirname,"public");
const allowed=new Set(["EURUSD_otc","GBPUSD_otc","USDJPY_otc","BTCUSD_otc","AUDUSD_otc"]);
const mime={".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css; charset=utf-8"};
const send=(r,s,d,t="application/json; charset=utf-8")=>{r.writeHead(s,{"Content-Type":t,"Cache-Control":"no-store"});r.end(typeof d==="string"?d:JSON.stringify(d));};
http.createServer(async(req,res)=>{
 const u=new URL(req.url,"http://localhost");
 if(u.pathname==="/api/candles"){
  if(!key)return send(res,503,{error:"Server-ka laguma darin OTCHARTS_API_KEY."});
  const symbol=u.searchParams.get("symbol")||"EURUSD_otc";
  if(!allowed.has(symbol))return send(res,400,{error:"Instrument-kan kuma jiro liiska Free-ka."});
  try{
   const r=await fetch("https://otcharts.com/v1/candles?venue=otc&symbol="+encodeURIComponent(symbol)+"&tf=60&limit=100",{headers:{Authorization:"Bearer "+key,Accept:"application/json"}});
   const d=await r.json();return send(res,r.status,r.ok?d:{error:d.error||d.message||"OTCharts API error",details:d});
  }catch(e){return send(res,502,{error:"Xogta OTCharts lama soo qaadi karin."});}
 }
 const rel=u.pathname==="/ "||u.pathname==="/"?"index.html":u.pathname.replace(/^\\/+/,"");
 const f=path.resolve(root,rel);
 if(!f.startsWith(root+path.sep)&&f!==path.join(root,"index.html"))return send(res,403,"Forbidden","text/plain");
 fs.readFile(f,(e,b)=>e?send(res,404,"Not found","text/plain"):send(res,200,b,mime[path.extname(f)]||"application/octet-stream"));
}).listen(port,()=>console.log("RAAZ AI PRO: http://localhost:"+port));
